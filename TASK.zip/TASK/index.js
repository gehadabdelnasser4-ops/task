
// 1. Student Class

class Student {
    constructor(id, name, grades, attendance) {
        this.id = id;
        this.name = name;
        this.grades = grades;
        this.attendance = attendance;
    }

    // Calculate Average using reduce
    calculateAverage() {
        const total = this.grades.reduce((sum, grade) => {
            return sum + grade;
        }, 0);

        return total / this.grades.length;
    }

    // Calculate Grade
    getGrade(average) {
        if (average >= 90) {
            return "A";
        } else if (average >= 80) {
            return "B";
        } else if (average >= 70) {
            return "C";
        } else if (average >= 60) {
            return "D";
        } else if (average >= 50) {
            return "E";
        } else {
            return "F";
        }
    }

    // Check Final Result

    getFinalResult() {
        const average = this.calculateAverage();

        if (average >= 50 && this.attendance >= 75) {
            return "ناجح";
        } else {
            return "يحتاج مراجعة";
        }
    }
}


// 2. Students List

const studentsList = [
    new Student(101, "Ayman", [90, 85, 95], 90),
    new Student(102, "Gehad", [45, 48, 42], 80),
    new Student(103, "Osama", [40, 45, 48], 85),
    new Student(104, "Nasser", [30, 35, 40], 60)
];


// 3. Display Students Reports

console.log("========== Students Reports ==========");

studentsList.forEach((student) => {
    const average = student.calculateAverage();
    const grade = student.getGrade(average);
    const result = student.getFinalResult();

    console.log("Student Name:", student.name);
    console.log("Average:", average.toFixed(2));
    console.log("Grade:", grade);
    console.log("Final Result:", result);
    console.log("--------------------------------------");
});


// 4. Mercy Committee - Filter

const strugglingStudents = studentsList.filter((student) => {
    const average = student.calculateAverage();

    return average >= 40 && average <= 49;
});


// 5. Add 5 Mercy Marks using Map

const mercyStudents = strugglingStudents.map((student) => {
    const oldAverage = student.calculateAverage();
    const newAverage = oldAverage + 5;

    return {
        id: student.id,
        name: student.name,
        oldAverage: oldAverage,
        newAverage: newAverage
    };
});


// 6. Calculate Total using Reduce

const totalNewAverages = mercyStudents.reduce((sum, student) => {
    return sum + student.newAverage;
}, 0);


// 7. Calculate Mercy Average

const mercyAverage = mercyStudents.length > 0
    ? totalNewAverages / mercyStudents.length
    : 0;


// 8. Display Mercy Committee Report

console.log("========== Mercy Committee ==========");

console.log("Struggling Students:", mercyStudents);

console.log("Average After Mercy:", mercyAverage.toFixed(2));

console.log("======================================");
